package com.saundaryasapplication.app.modules.androidlargefour.`data`.model

import com.saundaryasapplication.app.R
import com.saundaryasapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidLargeFourModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMyAgroDhan: String? = MyApp.getInstance().resources.getString(R.string.lbl_my_agrodhan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAurangabad: String? = MyApp.getInstance().resources.getString(R.string.lbl_aurangabad)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_we_solved_100)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCottonAnthracn: String? =
      MyApp.getInstance().resources.getString(R.string.msg_cotton_anthracn)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCornleafdisea: String? =
      MyApp.getInstance().resources.getString(R.string.msg_corn_leaf_disea)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHome: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSearch: String? = MyApp.getInstance().resources.getString(R.string.lbl_search)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwelveValue: String? = null
)
