package com.saundaryasapplication.app.modules.androidlargefour.ui

import androidx.activity.viewModels
import com.saundaryasapplication.app.R
import com.saundaryasapplication.app.appcomponents.base.BaseActivity
import com.saundaryasapplication.app.databinding.ActivityAndroidLargeFourBinding
import com.saundaryasapplication.app.modules.androidlargefour.`data`.viewmodel.AndroidLargeFourVM
import kotlin.String
import kotlin.Unit

class AndroidLargeFourActivity :
    BaseActivity<ActivityAndroidLargeFourBinding>(R.layout.activity_android_large_four) {
  private val viewModel: AndroidLargeFourVM by viewModels<AndroidLargeFourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidLargeFourVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ANDROID_LARGE_FOUR_ACTIVITY"

  }
}
